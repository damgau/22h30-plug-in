/*
 * Panneau 22H30 : tout ce qui parle à Premiere (ExtendScript).
 *
 * C'est le seul fichier qui agit sur Premiere. Le jour où le bureau passera en Premiere 27,
 * c'est lui qu'il faudra réécrire pour UXP ; le reste du panneau ne changera pas.
 *
 * Le panneau le charge à chaque ouverture ($.evalFile), pour qu'une mise à jour le recharge aussi.
 * Tout est rangé dans l'objet P2230, pour ne pas gêner les autres extensions.
 */

var P2230 = P2230 || {};

/* Étape 1 : une seule fonction, qui prouve que le pont panneau ↔ Premiere fonctionne. */
P2230.versionPremiere = function () {
    return String(app.version);
};

/* Chemin complet du projet ouvert (.prproj), ou "" si aucun projet n'est enregistré. Lecture seule. */
P2230.cheminProjet = function () {
    if (!app.project || !app.project.path) return "";
    return String(app.project.path);
};
