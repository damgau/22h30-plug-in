/*
 * Panneau 22H30 : trouver les sources de la fiche du jour, avec des garde-fous (Node.js).
 *
 * Au bureau, chaque numéro a son dossier : <dossier de la personne>/JJMM 2230/, qui contient le projet
 * (2230_V2.prproj, dupliqué depuis « template 2230 ») et AAMMJJ Sujets/ (PDF et MXF copiés du serveur).
 * Le conducteur est le dernier « Conduites 22h30*.xlsx » téléchargé depuis Google Sheets.
 *
 * Chaque fonction renvoie des alertes { niveau: 'bloquant' | 'attention' | 'info', texte }.
 * Relit aussi la dernière fiche enregistrée dans le dossier du jour et dit ce qui a changé depuis
 * (conducteur plus récent, PDF ajoutés, modifiés ou retirés).
 * Utilisé par js/fiche_panneau.js et par essais/essai_dossier_du_jour.js. Écrit pour Node 8 (CEP 9).
 */
'use strict';

var fs = require('fs');
var path = require('path');
var os = require('os');

// « Conduites 22h30.xlsx » (nom donné par Google Sheets), « Conduites 22h30 (1).xlsx », « Conduites 22h30(2).xlsx »,
// « Conduites 22h30.xlsx (1) », et les mêmes avec un tiret bas (« Conduites_22h30.xlsx »).
var MOTIF_CONDUCTEUR = /^conduites[ _]22h30\s*(\(\d+\))?\.xlsx(\s*\(\d+\))?$/i;
var MOTIF_DOSSIER_JOUR = /^(\d{2})(\d{2}) 2230$/;
var MOTIF_SUJETS = /^\d{6} sujets$/i;

function deux(n) { return (n < 10 ? '0' : '') + n; }
function jjmm(date) { return deux(date.getDate()) + deux(date.getMonth() + 1); }
function aammjj(date) { return String(date.getFullYear()).slice(2) + deux(date.getMonth() + 1) + deux(date.getDate()); }
function jourLisible(date) { return deux(date.getDate()) + '/' + deux(date.getMonth() + 1); }
function heure(date) { return deux(date.getHours()) + ':' + deux(date.getMinutes()); }
function memeJour(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function alerte(niveau, texte) { return { niveau: niveau, texte: texte }; }

function lister(dossier) {
  try { return fs.readdirSync(dossier); } catch (e) { return null; }
}

function estDossier(chemin) {
  try { return fs.statSync(chemin).isDirectory(); } catch (e) { return false; }
}

function dossierTelechargements() {
  return path.join(os.homedir(), 'Downloads');
}

/* « Conduites 22h30.xlsx (1) » -> « Conduites 22h30 (1).xlsx » : la fiche veut un nom en .xlsx. */
function nomEnXlsx(nom) {
  var m = /^(.*?)\.xlsx\s*(\(\d+\))$/i.exec(nom);
  return m ? m[1] + ' ' + m[2] + '.xlsx' : nom;
}

/* Le dernier export du conducteur d'un dossier (Téléchargements). */
function trouverConducteur(dossier, date) {
  var noms = lister(dossier);
  if (!noms) return { conducteur: null, alertes: [alerte('bloquant', 'Dossier illisible : ' + dossier)] };
  var candidats = noms.filter(function (n) { return MOTIF_CONDUCTEUR.test(n); }).map(function (n) {
    var chemin = path.join(dossier, n);
    try {
      var info = fs.statSync(chemin);
      return info.isFile() ? { nom: n, chemin: chemin, date: info.mtime, taille: info.size } : null;
    } catch (e) {
      return null;
    }
  }).filter(Boolean).sort(function (a, b) { return b.date - a.date; });

  if (!candidats.length) {
    return { conducteur: null, alertes: [alerte('bloquant',
      'Aucun « Conduites 22h30.xlsx » dans Téléchargements : téléchargez le conducteur (Fichier > Télécharger > Microsoft Excel).')] };
  }
  var c = candidats[0];
  c.nomPourFiche = nomEnXlsx(c.nom);
  var alertes = [];
  if (!memeJour(c.date, date)) {
    alertes.push(alerte('attention', 'Le dernier export du conducteur date du ' + jourLisible(c.date) + ' à ' + heure(c.date) +
      ' : téléchargez-le à nouveau.'));
  }
  if (c.taille === 0) alertes.push(alerte('bloquant', '« ' + c.nom + ' » est vide : téléchargement interrompu ?'));
  return { conducteur: c, autres: candidats.length - 1, alertes: alertes };
}

/* Clé qui relie un PDF à son MXF : le code du sujet (« AVC-RTC-185469 », « NOTELE-231737 »), sinon le nom sans
   extension. Notélé ne nomme pas les deux pareil : « NOTELE - 231737 Fiche Sequence.pdf » et
   « NOTELE - 231737 - projet …_XDCAMHD422.mxf » (05/11). */
function cleSujet(nom) {
  var avc = /^(AVC-[A-Z0-9]+-\d+)/i.exec(nom);
  if (avc) return avc[1].toUpperCase();
  var notele = /^NOTELE\s*-\s*(\d+)/i.exec(nom);
  if (notele) return 'NOTELE-' + notele[1];
  return nom.replace(/\.[^.]+$/, '').toLowerCase();
}

/* PDF et MXF d'un dossier de sujets, avec les oublis de copie les plus probables. */
function listerSujets(dossier) {
  var noms = (lister(dossier) || []).filter(function (n) { return n.charAt(0) !== '.'; });
  var base = cleSujet;
  var pdfs = noms.filter(function (n) { return /\.pdf$/i.test(n); }).sort();
  var mxfs = noms.filter(function (n) { return /\.mxf$/i.test(n); }).sort();
  var basesMxf = mxfs.map(base);
  var basesPdf = pdfs.map(base);
  var alertes = [];

  pdfs.forEach(function (n) {
    if (basesMxf.indexOf(base(n)) < 0) alertes.push(alerte('attention', '« ' + n + ' » : pas de MXF avec ce code dans le dossier (média pas encore copié ?).'));
  });
  var mxfSeuls = mxfs.filter(function (n) { return basesPdf.indexOf(base(n)) < 0; });
  if (mxfSeuls.length) {
    alertes.push(alerte('info', mxfSeuls.length + ' MXF sans PDF (normal pour Matélé et BX1) : ' + mxfSeuls.join(', ') + '.'));
  }
  pdfs.concat(mxfs).forEach(function (n) {
    try {
      if (fs.statSync(path.join(dossier, n)).size === 0) alertes.push(alerte('attention', '« ' + n + ' » est vide : copie interrompue ?'));
    } catch (e) { /* disparu entre-temps */ }
  });
  if (!pdfs.length) alertes.push(alerte('attention', 'Aucun PDF dans « ' + path.basename(dossier) + ' ».'));
  return { pdfs: pdfs, mxfs: mxfs, alertes: alertes };
}

/* Dossier du jour : nom, dossier des sujets, garde-fous. */
function analyserDossierJour(dossierJour, date, nomProjet) {
  var nom = path.basename(dossierJour);
  var attendu = aammjj(date) + ' Sujets';
  var resultat = {
    dossierJour: dossierJour, nomDossier: nom, nomProjet: nomProjet || null, dossierAttendu: jjmm(date) + ' 2230',
    sujetsAttendus: attendu, dossierSujets: null, pdfs: [], mxfs: [], enregistrable: true, alertes: []
  };
  var alertes = resultat.alertes;

  if (/template/i.test(nom)) {
    resultat.enregistrable = false;
    alertes.push(alerte('bloquant', 'Le projet ouvert est le template (« ' + nom + ' ») : dupliquez-le en « ' +
      resultat.dossierAttendu + ' » et ouvrez la copie avant de monter.'));
  } else {
    var m = MOTIF_DOSSIER_JOUR.exec(nom);
    if (m && m[1] + m[2] !== jjmm(date)) {
      alertes.push(alerte('attention', 'Le projet ouvert est dans « ' + nom + ' » (le ' + m[1] + '/' + m[2] + '), pas dans « ' +
        resultat.dossierAttendu + ' ».'));
    } else if (!m) {
      alertes.push(alerte('info', 'Le dossier du projet (« ' + nom + ' ») ne suit pas le nom « JJMM 2230 ».'));
    }
  }

  var noms = lister(dossierJour);
  if (!noms) {
    resultat.enregistrable = false;
    alertes.push(alerte('bloquant', 'Dossier du jour illisible : ' + dossierJour));
    return resultat;
  }
  var sujets = noms.filter(function (n) { return n.toLowerCase() === attendu.toLowerCase() && estDossier(path.join(dossierJour, n)); })[0];
  var autres = noms.filter(function (n) {
    return MOTIF_SUJETS.test(n) && n.toLowerCase() !== attendu.toLowerCase() && estDossier(path.join(dossierJour, n));
  });

  if (!sujets) {
    alertes.push(alerte('bloquant', autres.length
      ? 'Le dossier des sujets est « ' + autres.join(' », « ') + ' », pas « ' + attendu + ' » : ce ne sont pas les sujets du jour.'
      : 'Pas de dossier « ' + attendu + ' » dans « ' + nom + ' » : copiez-le depuis le serveur.'));
    return resultat;
  }
  if (autres.length) alertes.push(alerte('attention', 'Le dossier du jour contient aussi « ' + autres.join(' », « ') + ' ».'));
  resultat.dossierSujets = path.join(dossierJour, sujets);
  var contenu = listerSujets(resultat.dossierSujets);
  resultat.pdfs = contenu.pdfs;
  resultat.mxfs = contenu.mxfs;
  contenu.alertes.forEach(function (a) { alertes.push(a); });
  return resultat;
}

/* À partir du chemin du projet ouvert dans Premiere (vide si aucun projet enregistré). */
function analyserProjet(cheminProjet, date) {
  var chemin = String(cheminProjet || '').replace(/^\\\\\?\\/, '');
  if (!chemin || !/\.prproj$/i.test(chemin)) {
    return { dossierJour: null, dossierSujets: null, pdfs: [], mxfs: [], enregistrable: false,
      alertes: [alerte('attention', 'Aucun projet enregistré n\'est ouvert dans Premiere : ouvrez le projet du jour, ou choisissez son dossier.')] };
  }
  return analyserDossierJour(path.dirname(chemin), date, path.basename(chemin));
}

/* ---------- Dernière fiche enregistrée ---------- */

function dateModif(chemin) {
  try { return fs.statSync(chemin).mtime; } catch (e) { return null; }
}

/* Ce que le panneau range dans le JSON de la fiche (clé « sources_panneau ») pour savoir, plus tard,
   si le conducteur ou les PDF ont changé depuis. */
function empreinteSources(conducteur, analyse, maintenant) {
  var pdfs = {};
  (analyse.pdfs || []).forEach(function (n) {
    var d = analyse.dossierSujets ? dateModif(path.join(analyse.dossierSujets, n)) : null;
    pdfs[n] = d ? d.toISOString() : null;
  });
  return {
    genere_le: maintenant.toISOString(),
    conducteur: conducteur ? { nom: conducteur.nom, modifie_le: conducteur.date.toISOString() } : null,
    pdfs: pdfs
  };
}

/* fiche_AAMMJJ.html (et .json) du dossier du jour, ou null. */
function lireDerniereFiche(dossierJour, date) {
  if (!dossierJour) return null;
  var base = path.join(dossierJour, 'fiche_' + aammjj(date));
  var html;
  try { html = fs.readFileSync(base + '.html', 'utf8'); } catch (e) { return null; }
  var fiche = null;
  try { fiche = JSON.parse(fs.readFileSync(base + '.json', 'utf8')); } catch (e) { fiche = null; }
  var sources = fiche && fiche.sources_panneau ? fiche.sources_panneau : null;
  var genereLe = sources && sources.genere_le ? new Date(sources.genere_le) : dateModif(base + '.html');
  return { chemin: base + '.html', html: html, fiche: fiche, sources: sources, genereLe: genereLe };
}

function plusRecent(a, b) { return a && b && a.getTime() > b.getTime() + 1000; }  // 1 s de marge (dates des disques)

function liste(noms) { return noms.length > 3 ? noms.slice(0, 3).join(', ') + '…' : noms.join(', '); }

/* Ce qui a changé depuis la dernière fiche : textes courts, vides si rien. Sans sources_panneau (fiche d'une
   version plus ancienne du panneau), on compare seulement les dates avec celle de la fiche. */
function changementsDepuis(derniere, conducteur, analyse) {
  if (!derniere) return [];
  var changements = [];
  var s = derniere.sources;
  if (conducteur) {
    var avant = s && s.conducteur;
    var autre = avant ? (conducteur.nom !== avant.nom || plusRecent(conducteur.date, new Date(avant.modifie_le)))
      : plusRecent(conducteur.date, derniere.genereLe);
    if (autre) {
      changements.push('conducteur plus récent (« ' + conducteur.nom + ' », téléchargé le ' + jourLisible(conducteur.date) +
        ' à ' + heure(conducteur.date) + ')');
    }
  }
  var nouveaux = [], modifies = [];
  (analyse.pdfs || []).forEach(function (n) {
    var d = analyse.dossierSujets ? dateModif(path.join(analyse.dossierSujets, n)) : null;
    if (s && s.pdfs) {
      if (!Object.prototype.hasOwnProperty.call(s.pdfs, n)) nouveaux.push(n);
      else if (s.pdfs[n] && plusRecent(d, new Date(s.pdfs[n]))) modifies.push(n);
    } else if (plusRecent(d, derniere.genereLe)) {
      modifies.push(n);
    }
  });
  var retires = s && s.pdfs ? Object.keys(s.pdfs).filter(function (n) { return (analyse.pdfs || []).indexOf(n) < 0; }) : [];
  if (nouveaux.length) changements.push(nouveaux.length + (nouveaux.length > 1 ? ' nouveaux PDF (' : ' nouveau PDF (') + liste(nouveaux) + ')');
  if (modifies.length) {
    var pluriel = modifies.length > 1 ? 's' : '';
    changements.push((s ? 'PDF modifié' + pluriel : 'PDF plus récent' + pluriel + ' que la fiche') + ' (' + liste(modifies) + ')');
  }
  if (retires.length) changements.push('PDF retiré' + (retires.length > 1 ? 's' : '') + ' du dossier (' + liste(retires) + ')');
  return changements;
}

module.exports = {
  jjmm: jjmm,
  aammjj: aammjj,
  heure: heure,
  jourLisible: jourLisible,
  nomEnXlsx: nomEnXlsx,
  dossierTelechargements: dossierTelechargements,
  trouverConducteur: trouverConducteur,
  listerSujets: listerSujets,
  cleSujet: cleSujet,
  empreinteSources: empreinteSources,
  lireDerniereFiche: lireDerniereFiche,
  changementsDepuis: changementsDepuis,
  analyserDossierJour: analyserDossierJour,
  analyserProjet: analyserProjet
};
