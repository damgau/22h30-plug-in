/*
 * Panneau 22H30 : page « Fiche du jour ».
 *
 * 1. Charge Python dès l'ouverture (js/fiche_python.js).
 * 2. Trouve les sources (js/dossier_du_jour.js) : le dossier du jour d'après le projet ouvert dans Premiere
 *    (ou choisi à la main), AAMMJJ Sujets dans ce dossier, le dernier « Conduites 22h30*.xlsx » de Téléchargements.
 *    Affiche les garde-fous.
 * 3. Génère la fiche, l'affiche dans le panneau et l'enregistre dans le dossier du jour
 *    (fiche_AAMMJJ.html et fiche_AAMMJJ.json, avec les sources utilisées dans « sources_panneau »).
 * 4. À l'ouverture, recharge la dernière fiche enregistrée et dit ce qui a changé depuis (conducteur, PDF).
 *    Revérifie toutes les 2 minutes.
 * 5. Les liens de la fiche (« Chercher sur le site ») s'ouvrent dans le navigateur par défaut.
 *
 * Les modules de Node sont pris au démarrage : pendant le chargement de Python, les globales de Node
 * sont mises de côté (voir fiche_python.js), mais nos références restent valables.
 */
(function () {
  'use strict';

  function el(id) { return document.getElementById(id); }

  var cep = window.__adobe_cep__;
  if (!cep || typeof require !== 'function') {
    el('python').textContent = 'Cette page doit être ouverte dans le panneau 22H30 de Premiere.';
    el('python').className = 'aide erreur';
    return;
  }

  var nodeRequire = require;
  var fs = nodeRequire('fs');
  var path = nodeRequire('path');
  var childProcess = nodeRequire('child_process');
  var plateforme = process.platform;

  function dossierExtension() {
    var brut = decodeURI(cep.getSystemPath('extension'));
    brut = plateforme === 'win32' ? brut.replace(/^file:\/\/\//, '') : brut.replace(/^file:\/\//, '');
    return path.normalize(brut);
  }

  var dossier = dossierExtension();
  var DJ = nodeRequire(path.join(dossier, 'js', 'dossier_du_jour.js'));
  var config = JSON.parse(el('config').textContent);

  var py = null;
  var analyse = null;      // dossier du jour
  var recherche = null;    // conducteur
  var dossierChoisi = null;
  var derniereFiche = null;    // chemin de la fiche enregistrée (lien « Ouvrir dans le navigateur »)
  var ficheAffichee = null;    // { cle: 'AAMMJJ', dossier, derniere: { chemin, genereLe, sources } }
  var REVERIFIER_MS = 2 * 60 * 1000;

  /* ---------- Date ---------- */

  var champDate = el('date');
  (function () {
    var d = new Date();
    champDate.value = d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  })();
  function dateChoisie() {
    var p = champDate.value.split('-');
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  }

  /* Le navigateur de Premiere affiche la date à l'américaine (11/05/2026 pour le 5 novembre) : on l'écrit en toutes lettres. */
  var JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  var MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  function ecrireDate() {
    var d = dateChoisie();
    el('date-texte').textContent = isNaN(d.getTime()) ? '' :
      JOURS[d.getDay()] + ' ' + d.getDate() + (d.getDate() === 1 ? 'er' : '') + ' ' + MOIS[d.getMonth()] + ' ' + d.getFullYear();
  }
  ecrireDate();

  /* ---------- Python ---------- */

  var debut = Date.now();
  FichePython.charger(config, function (etape) { el('python').textContent = 'Python : ' + etape + '…'; })
    .then(function (p) {
      py = p;
      el('python').textContent = 'Python prêt (' + ((Date.now() - debut) / 1000).toFixed(1) + ' s).';
      el('python').className = 'aide ok';
      majBouton();
    })
    .catch(function (erreur) {
      el('python').textContent = 'Python n\'a pas pu se charger : ' + erreur.message +
        ' Il faut internet. Utiliser « Ouvrir la fiche dans le navigateur » sur la page du panneau.';
      el('python').className = 'aide erreur';
    });

  /* ---------- Sources ---------- */

  function ligne(niveau, texte) {
    var li = document.createElement('li');
    li.className = niveau;
    li.textContent = texte;
    el('sources').appendChild(li);
  }

  function cheminProjet(rappel) {
    var hote = path.join(dossier, 'jsx', 'host.jsx').replace(/\\/g, '/').replace(/"/g, '\\"');
    cep.evalScript('$.evalFile("' + hote + '")', function () {
      cep.evalScript('P2230.cheminProjet()', function (reponse) {
        rappel(reponse && reponse.indexOf('EvalScript error') < 0 && reponse !== 'undefined' ? reponse : '');
      });
    });
  }

  function afficherSources() {
    el('sources').textContent = '';
    var date = dateChoisie();

    if (analyse.dossierJour) {
      var bon = analyse.nomDossier === analyse.dossierAttendu;
      ligne(bon ? 'ok' : 'attention',
        'Dossier du jour : ' + analyse.nomDossier + (analyse.nomProjet ? ' (' + analyse.nomProjet + ')' : ''));
    }
    if (analyse.dossierSujets) {
      ligne('ok', 'Sujets : ' + path.basename(analyse.dossierSujets) + ' — ' + analyse.pdfs.length + ' PDF, ' + analyse.mxfs.length + ' MXF');
    }
    analyse.alertes.forEach(function (a) { ligne(a.niveau, a.texte); });

    if (recherche.conducteur) {
      var c = recherche.conducteur;
      ligne(recherche.alertes.length ? 'attention' : 'ok', 'Conducteur : ' + c.nom + ' (téléchargé le ' + DJ.jourLisible(c.date) +
        ' à ' + DJ.heure(c.date) + ')');
    }
    recherche.alertes.forEach(function (a) { ligne(a.niveau, a.texte); });

    el('choisir-dossier').hidden = !(cep && window.cep && window.cep.fs && window.cep.fs.showOpenDialog);
    if (DJ.jjmm(date) !== DJ.jjmm(new Date())) ligne('info', 'Attention : la date choisie n\'est pas celle d\'aujourd\'hui.');
    suivreFiche();
  }

  /* ---------- Fiche affichée ---------- */

  function montrerFiche(html) {
    var cadre = el('fiche');
    cadre.srcdoc = html;
    cadre.hidden = false;
  }

  /* Dernière fiche du jour choisi : rechargée depuis le dossier du jour quand on change de jour ou de dossier. */
  function suivreFiche() {
    var date = dateChoisie();
    var cle = DJ.aammjj(date);
    var dossierJour = analyse && analyse.enregistrable ? analyse.dossierJour : null;
    if (!ficheAffichee || ficheAffichee.cle !== cle || ficheAffichee.dossier !== dossierJour) {
      var d = DJ.lireDerniereFiche(dossierJour, date);
      var resultat = el('resultat');
      if (d) {
        montrerFiche(d.html);
        ficheAffichee = { cle: cle, dossier: dossierJour, derniere: d };
        derniereFiche = d.chemin;
        resultat.textContent = 'Dernière fiche rechargée' + (d.genereLe ? ' : générée le ' + DJ.jourLisible(d.genereLe) +
          ' à ' + DJ.heure(d.genereLe) : '') + ' (' + path.basename(d.chemin) + ').';
        resultat.className = 'aide ok';
      } else {
        ficheAffichee = null;
        derniereFiche = null;
        el('fiche').hidden = true;
        resultat.textContent = '';
        resultat.className = 'aide';
      }
      el('liens').hidden = !derniereFiche;
    }
    afficherChangements();
    majBouton();
  }

  function afficherChangements() {
    var zone = el('changements');
    var c = ficheAffichee && analyse && recherche
      ? DJ.changementsDepuis(ficheAffichee.derniere, recherche.conducteur, analyse) : [];
    zone.textContent = c.length ? 'Depuis cette fiche : ' + c.join(' ; ') + '. Régénérez-la.' : '';
    zone.hidden = !c.length;
  }

  /* Les liens de la fiche s'ouvrent dans le navigateur par défaut. Dans le panneau, « Chercher sur le site »
     remplaçait la fiche par Google (05/11), et il fallait la régénérer. */
  function ouvrirAdresse(adresse) {
    if (window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === 'function') {
      window.cep.util.openURLInDefaultBrowser(adresse);
      return;
    }
    childProcess.execFile(plateforme === 'win32' ? 'explorer.exe' : '/usr/bin/open', [adresse], function () {});
  }

  function brancherLiens() {
    var doc;
    try { doc = el('fiche').contentDocument; } catch (e) { return; }
    if (!doc) return;
    var surClic = function (evenement) {
      var cible = evenement.target;
      var lien = cible && cible.closest ? cible.closest('a[href]') : null;
      if (!lien) return;
      var adresse = lien.getAttribute('href') || '';
      if (adresse.charAt(0) === '#') return;
      evenement.preventDefault();
      if (/^https?:\/\//i.test(adresse)) ouvrirAdresse(adresse);
    };
    doc.addEventListener('click', surClic, true);
    doc.addEventListener('auxclick', surClic, true);
  }

  function detecter() {
    var date = dateChoisie();
    recherche = DJ.trouverConducteur(DJ.dossierTelechargements(), date);
    if (dossierChoisi) {
      analyse = DJ.analyserDossierJour(dossierChoisi, date, null);
      afficherSources();
      return;
    }
    cheminProjet(function (chemin) {
      analyse = DJ.analyserProjet(chemin, date);
      afficherSources();
    });
  }

  function choisirDossier() {
    var depart = analyse && analyse.dossierJour ? path.dirname(analyse.dossierJour) : '';
    var reponse = window.cep.fs.showOpenDialog(false, true, 'Dossier du jour (JJMM 2230)', depart);
    if (reponse && !reponse.err && reponse.data && reponse.data.length) {
      dossierChoisi = reponse.data[0];
      detecter();
    }
  }

  function bloquants() {
    return (analyse ? analyse.alertes : []).concat(recherche ? recherche.alertes : [])
      .filter(function (a) { return a.niveau === 'bloquant'; });
  }

  function majBouton() {
    el('generer').disabled = !(py && analyse && analyse.dossierSujets && recherche && recherche.conducteur && !bloquants().length);
    el('generer').textContent = ficheAffichee ? 'Régénérer la fiche' : 'Générer la fiche';
  }

  /* ---------- Génération ---------- */

  function octets(chemin) {
    var b = fs.readFileSync(chemin);
    return new Uint8Array(b.buffer, b.byteOffset, b.length);
  }

  function generer() {
    var date = dateChoisie();
    var resultat = el('resultat');
    resultat.className = 'aide';
    resultat.textContent = 'Génération de la fiche…';
    el('generer').disabled = true;

    // Laisse le message s'afficher avant le calcul (quelques secondes, page figée pendant ce temps).
    setTimeout(function () {
      var r;
      try {
        r = FichePython.generer(py, {
          date: champDate.value,
          conducteur: { nom: recherche.conducteur.nomPourFiche, octets: octets(recherche.conducteur.chemin) },
          pdfs: analyse.pdfs.map(function (n) { return { nom: n, octets: octets(path.join(analyse.dossierSujets, n)) }; })
        });
      } catch (erreur) {
        resultat.textContent = 'La fiche n\'a pas pu être générée : ' + erreur.message;
        resultat.className = 'aide erreur';
        majBouton();
        return;
      }

      var maintenant = new Date();
      var sources = DJ.empreinteSources(recherche.conducteur, analyse, maintenant);
      montrerFiche(r.html);

      // Alertes générales de la fiche + alertes de chaque position (celles qu'on voit dans les cartes).
      var alertes = (r.fiche.alertes || []).length;
      (r.fiche.positions || []).forEach(function (p) { alertes += (p.alertes || []).length; });
      var message = 'Fiche générée à ' + DJ.heure(new Date()) + ', ' + alertes + ' point' + (alertes > 1 ? 's' : '') + ' à vérifier.';
      derniereFiche = null;
      if (analyse.enregistrable && analyse.dossierJour) {
        var base = path.join(analyse.dossierJour, 'fiche_' + DJ.aammjj(date));
        var fiche = r.fiche;
        fiche.sources_panneau = sources;   // pour dire plus tard ce qui a changé depuis cette fiche
        try {
          fs.writeFileSync(base + '.html', r.html, 'utf8');
          fs.writeFileSync(base + '.json', JSON.stringify(fiche, null, 2) + '\n', 'utf8');
          derniereFiche = base + '.html';
          message += ' Enregistrée dans « ' + analyse.nomDossier + ' » (' + path.basename(base) + '.html et .json).';
        } catch (e) {
          message += ' Pas enregistrée : ' + e.message;
        }
      } else {
        message += ' Pas enregistrée (dossier du jour inconnu ou template).';
      }
      resultat.textContent = message;
      resultat.className = 'aide ok';
      el('liens').hidden = !derniereFiche;
      ficheAffichee = {
        cle: DJ.aammjj(date),
        dossier: analyse.enregistrable ? analyse.dossierJour : null,
        derniere: { chemin: derniereFiche, genereLe: maintenant, sources: sources }
      };
      afficherChangements();
      majBouton();
    }, 30);
  }

  function ouvrirDansNavigateur(evenement) {
    evenement.preventDefault();
    if (!derniereFiche) return;
    childProcess.execFile(plateforme === 'win32' ? 'explorer.exe' : '/usr/bin/open', [derniereFiche], function () {});
  }

  /* ---------- Branchements ---------- */

  el('fiche').addEventListener('load', brancherLiens);
  el('generer').addEventListener('click', generer);
  el('actualiser').addEventListener('click', function (e) { e.preventDefault(); detecter(); });
  el('choisir-dossier').addEventListener('click', function (e) { e.preventDefault(); choisirDossier(); });
  el('ouvrir-navigateur').addEventListener('click', ouvrirDansNavigateur);
  champDate.addEventListener('change', function () { ecrireDate(); detecter(); });

  detecter();
  // Nouveau conducteur téléchargé, nouveaux PDF copiés ? On revérifie sans attendre « Actualiser ».
  setInterval(detecter, REVERIFIER_MS);
})();
