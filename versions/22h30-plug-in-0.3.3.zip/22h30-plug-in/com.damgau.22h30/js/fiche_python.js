/*
 * Panneau 22H30 : la fiche du jour en Python (Pyodide), dans la page du panneau.
 *
 * Même démarrage que la version navigateur (src/fiche_navigateur/modele.html) : pyodide.js, micropip,
 * openpyxl et pdfplumber, puis le code de src/fiche_du_jour/ (embarqué dans la page par construire.py).
 *
 * Différence avec le navigateur : le panneau a aussi Node.js (contexte mixte de CEP). Pyodide le verrait,
 * se croirait dans Node et échouerait (« node:module », essai du 05/11). On met donc les globales de Node
 * de côté pendant le chargement, puis on les remet.
 *
 * Aucune dépendance à Node ici : utilisable aussi dans un navigateur ordinaire (essais).
 */
var FichePython = (function () {
  'use strict';

  var RACINE = '/app';
  var GLOBALES_NODE = ['process', 'require', 'module', 'exports', 'global', 'Buffer', '__filename', '__dirname'];

  function masquerNode() {
    var miseDeCote = {};
    var restees = [];
    GLOBALES_NODE.forEach(function (nom) {
      if (typeof window[nom] === 'undefined') return;
      miseDeCote[nom] = window[nom];
      try { delete window[nom]; } catch (e) { /* non supprimable */ }
      if (typeof window[nom] !== 'undefined') {
        try { Object.defineProperty(window, nom, { value: undefined, configurable: true, writable: true }); } catch (e2) { /* figée */ }
      }
      if (typeof window[nom] !== 'undefined') {
        try { window[nom] = undefined; } catch (e3) { /* lecture seule */ }
      }
      if (typeof window[nom] !== 'undefined') restees.push(nom);
    });
    return {
      restees: restees,
      remettre: function () {
        Object.keys(miseDeCote).forEach(function (nom) {
          try { window[nom] = miseDeCote[nom]; } catch (e) { /* sans gravité */ }
        });
      }
    };
  }

  function chargerScript(adresse) {
    return new Promise(function (resoudre, rejeter) {
      var s = document.createElement('script');
      s.src = adresse;
      s.onload = function () { resoudre(); };
      s.onerror = function () { rejeter(new Error('pyodide.js n\'a pas pu être téléchargé (internet ?)')); };
      document.head.appendChild(s);
    });
  }

  /* Fichiers de la fiche embarqués dans la page : <script type="text/plain" class="fichier" data-chemin="…">. */
  function fichiersEmbarques() {
    var fichiers = {};
    var blocs = document.querySelectorAll('script.fichier');
    for (var i = 0; i < blocs.length; i++) {
      fichiers[blocs[i].getAttribute('data-chemin')] = blocs[i].textContent.replace(/<\\\/script/g, '</script');
    }
    return fichiers;
  }

  /* config : { pyodide, roues }. noter(texte) : étapes. Renvoie une promesse de Pyodide prêt. */
  function charger(config, noter) {
    noter = noter || function () {};
    var masque = masquerNode();
    if (masque.restees.length) noter('Node.js n\'a pas pu être mis de côté pour : ' + masque.restees.join(', '));
    var py;
    return chargerScript(config.pyodide + 'pyodide.js')
      .then(function () {
        if (typeof window.loadPyodide !== 'function') throw new Error('pyodide.js ne s\'exécute pas : navigateur trop ancien.');
        noter('démarrage de Python');
        return window.loadPyodide({ indexURL: config.pyodide });
      })
      .then(function (p) {
        py = p;
        noter('chargement des bibliothèques (openpyxl, pdfplumber)');
        return py.loadPackage(['micropip', 'cryptography', 'charset-normalizer']);
      })
      .then(function () {
        // deps=False : pdfplumber réclame pypdfium2 et Pillow, qui ne servent qu'à dessiner les pages.
        return py.pyimport('micropip').install.callKwargs(config.roues, { deps: false });
      })
      .then(function () {
        var fichiers = fichiersEmbarques();
        Object.keys(fichiers).forEach(function (chemin) {
          var complet = RACINE + '/' + chemin;
          py.FS.mkdirTree(complet.slice(0, complet.lastIndexOf('/')));
          py.FS.writeFile(complet, fichiers[chemin]);
        });
        py.runPython('import sys; sys.path.insert(0, "' + RACINE + '/src/fiche_du_jour")');
        masque.remettre();
        return py;
      })
      .catch(function (erreur) {
        masque.remettre();
        throw erreur;
      });
  }

  function viderDossier(py, chemin) {
    var FS = py.FS;
    if (!FS.analyzePath(chemin).exists) return;
    FS.readdir(chemin).forEach(function (nom) {
      if (nom === '.' || nom === '..') return;
      var p = chemin + '/' + nom;
      if (FS.isDir(FS.stat(p).mode)) { viderDossier(py, p); FS.rmdir(p); } else { FS.unlink(p); }
    });
  }

  function aammjj(iso) { return iso.slice(2, 4) + iso.slice(5, 7) + iso.slice(8, 10); }

  /*
   * sources : { date: 'AAAA-MM-JJ', conducteur: { nom, octets }, pdfs: [{ nom, octets }] }, octets en Uint8Array.
   * Renvoie { html, json, fiche } ; lève une erreur si la fiche ne peut pas être construite.
   */
  function generer(py, sources) {
    var FS = py.FS;
    var jour = aammjj(sources.date);
    viderDossier(py, RACINE + '/donnees');
    FS.mkdirTree(RACINE + '/donnees/conducteur');
    FS.mkdirTree(RACINE + '/donnees/sujets/' + jour);
    var cheminConducteur = RACINE + '/donnees/conducteur/' + sources.conducteur.nom;
    FS.writeFile(cheminConducteur, sources.conducteur.octets);
    sources.pdfs.forEach(function (f) { FS.writeFile(RACINE + '/donnees/sujets/' + jour + '/' + f.nom, f.octets); });

    py.globals.set('DATE', sources.date);
    py.globals.set('CONDUCTEUR', cheminConducteur);
    py.globals.set('SUJETS', RACINE + '/donnees/sujets/' + jour);
    var resultat = JSON.parse(py.runPython([
      'import datetime, json',
      'from fiche import construire',
      'from rendu import html',
      'try:',
      '    _fiche = construire(datetime.date.fromisoformat(DATE), CONDUCTEUR, SUJETS)',
      '    _r = {"html": html(_fiche), "json": json.dumps(_fiche, ensure_ascii=False, indent=2)}',
      'except SystemExit as e:',
      '    _r = {"erreur": str(e)}',
      'json.dumps(_r)'
    ].join('\n')));
    if (resultat.erreur) throw new Error(resultat.erreur);
    resultat.fiche = JSON.parse(resultat.json);
    return resultat;
  }

  return { charger: charger, generer: generer };
})();
