/*
 * Panneau 22H30 : essai de Python (Pyodide) dans le navigateur intégré à Premiere.
 *
 * Refait le démarrage de la fiche du jour (src/fiche_navigateur/modele.html) :
 * pyodide.js, loadPyodide, micropip, puis openpyxl et pdfplumber, puis un petit calcul Python.
 * Écrit en JavaScript ancien (ES5 + Promise) pour afficher un résultat même dans un vieux Chromium.
 */
(function () {
  'use strict';

  var journal = [];
  var debut = Date.now();

  function el(id) { return document.getElementById(id); }

  function noter(texte) {
    journal.push(((Date.now() - debut) / 1000).toFixed(1) + ' s · ' + texte);
    el('essai-notes').textContent = journal.join('\n');
  }

  function conclure(ok, message) {
    el('essai').className = 'maj ' + (ok ? 'ok' : 'erreur');
    el('essai-message').textContent = message;
  }

  // Navigateur intégré : la version de Chromium décide de la réussite.
  var chrome = /Chrome\/(\d+)/.exec(navigator.userAgent);
  el('essai-navigateur').textContent = 'Navigateur intégré : Chromium ' + (chrome ? chrome[1] : 'inconnu') +
    ' · WebAssembly : ' + (typeof WebAssembly === 'object' ? 'oui' : 'non');

  var config;
  try {
    config = JSON.parse(el('config').textContent);
  } catch (e) {
    conclure(false, 'Essai impossible : adresses de Pyodide absentes (page non construite par construire.py).');
    return;
  }

  // Dans le panneau, Node.js est aussi présent : sans ce réglage, Pyodide se croirait dans Node et chercherait
  // ses fichiers sur le disque au lieu de les télécharger.
  if (typeof process === 'object' && process) {
    try { process.browser = true; } catch (e) { /* sans gravité */ }
  }

  function chargerScript(adresse) {
    return new Promise(function (resoudre, rejeter) {
      var s = document.createElement('script');
      s.src = adresse;
      s.onload = function () { resoudre(); };
      s.onerror = function () { rejeter(new Error('pyodide.js n\'a pas pu être téléchargé (internet ?)')); };
      document.head.appendChild(s);
    });
  }

  // Une erreur de syntaxe dans pyodide.js (navigateur trop ancien) n'arrive que par window.onerror.
  var erreurScript = null;
  window.addEventListener('error', function (evenement) {
    if (evenement && evenement.filename && evenement.filename.indexOf('pyodide') >= 0) {
      erreurScript = evenement.message;
    }
  });

  noter('téléchargement de pyodide.js');
  chargerScript(config.pyodide + 'pyodide.js')
    .then(function () {
      if (typeof window.loadPyodide !== 'function') {
        throw new Error('pyodide.js est arrivé mais ne s\'exécute pas' + (erreurScript ? ' (' + erreurScript + ')' : '') +
          ' : navigateur trop ancien.');
      }
      noter('démarrage de Python');
      return window.loadPyodide({ indexURL: config.pyodide });
    })
    .then(function (py) {
      noter('Python démarré : ' + py.runPython('import sys; sys.version.split()[0]'));
      noter('chargement de micropip et des dépendances');
      return py.loadPackage(['micropip', 'cryptography', 'charset-normalizer']).then(function () { return py; });
    })
    .then(function (py) {
      noter('installation d\'openpyxl et de pdfplumber');
      var micropip = py.pyimport('micropip');
      return micropip.install.callKwargs(config.roues, { deps: false }).then(function () { return py; });
    })
    .then(function (py) {
      var versions = py.runPython('import openpyxl, pdfplumber; f"openpyxl {openpyxl.__version__}, pdfplumber {pdfplumber.__version__}"');
      noter('bibliothèques prêtes : ' + versions);
      var total = ((Date.now() - debut) / 1000).toFixed(1);
      conclure(true, 'Réussi : Python et les bibliothèques de la fiche démarrent dans le panneau (' + total + ' s).');
    })
    .catch(function (erreur) {
      noter('arrêt : ' + (erreur && erreur.message ? erreur.message : String(erreur)));
      conclure(false, 'Échec : Python ne démarre pas dans ce panneau. La fiche reste à ouvrir dans le navigateur.');
    });
})();
