@echo off
rem Installe le panneau 22H30 pour Premiere (Windows), une seule fois.
rem - copie le dossier com.damgau.22h30 dans le dossier CEP de l'utilisateur (sans droits d'administrateur) ;
rem - active le mode debogage CEP (PlayerDebugMode), qui autorise un panneau non signe par Adobe.
rem Ensuite, les nouvelles versions arrivent par le bouton "Mettre a jour" du panneau.
rem (Texte sans accents : la console Windows les affiche mal.)

setlocal
set "ICI=%~dp0"
set "SOURCE=%ICI%com.damgau.22h30"
set "PARENT=%APPDATA%\Adobe\CEP\extensions"
set "CIBLE=%PARENT%\com.damgau.22h30"
set "DONNEES=%APPDATA%\22H30-plug-in"

echo Installation du panneau 22H30 pour Premiere
echo.

if not exist "%SOURCE%\CSXS\manifest.xml" (
  echo Erreur : le dossier com.damgau.22h30 est introuvable a cote de ce script.
  echo Decompressez d'abord le zip, puis lancez ce script depuis le dossier decompresse.
  pause
  exit /b 1
)

if not exist "%PARENT%" mkdir "%PARENT%"

if exist "%CIBLE%" (
  if not exist "%DONNEES%" mkdir "%DONNEES%"
  if exist "%DONNEES%\precedente" rmdir /s /q "%DONNEES%\precedente"
  move "%CIBLE%" "%DONNEES%\precedente" > nul
  echo Ancienne version mise de cote dans : %DONNEES%\precedente
)

xcopy "%SOURCE%" "%CIBLE%\" /e /i /q /y > nul
if errorlevel 1 (
  echo Erreur : la copie a echoue.
  pause
  exit /b 1
)

rem CSXS 9 = Premiere 2020 ; CSXS 12 = Premiere 25 et 26.
for %%v in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f > nul

echo Termine. Installe dans : %CIBLE%
echo.
echo Redemarrez Premiere, puis ouvrez Fenetre ^> Extensions ^> 22H30.
pause
