#!/bin/bash
# Désinstalle le panneau 22H30 (macOS) : supprime son dossier dans le dossier CEP de l'utilisateur.
# Le mode débogage CEP (PlayerDebugMode) reste actif, sauf si on répond « o » à la question.

CIBLE="$HOME/Library/Application Support/Adobe/CEP/extensions/com.damgau.22h30"

pause() {
  if [ -t 0 ]; then
    echo
    read -n 1 -s -r -p "Appuyez sur une touche pour fermer cette fenêtre."
    echo
  fi
}

if [ -d "$CIBLE" ]; then
  rm -rf "$CIBLE" && echo "Panneau 22H30 supprimé."
else
  echo "Le panneau 22H30 n'est pas installé."
fi

if [ -t 0 ]; then
  echo
  read -r -p "Désactiver aussi le mode débogage CEP (utile si aucun autre panneau non signé ne s'en sert) ? (o/N) " REPONSE
  if [ "$REPONSE" = "o" ] || [ "$REPONSE" = "O" ]; then
    for v in 9 10 11 12 13; do
      defaults write "com.adobe.CSXS.$v" PlayerDebugMode 0
    done
    killall cfprefsd 2> /dev/null
    echo "Mode débogage CEP désactivé."
  fi
fi

echo "Redémarrez Premiere pour que le panneau disparaisse du menu."
pause
