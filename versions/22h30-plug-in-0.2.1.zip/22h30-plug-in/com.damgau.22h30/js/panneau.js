/*
 * Panneau 22H30 : démarrage.
 *
 * Tourne dans la page du panneau (contexte mixte de CEP : navigateur + Node.js).
 * 1. Lit la version installée dans CSXS/manifest.xml.
 * 2. Charge jsx/host.jsx dans Premiere et affiche la version de Premiere.
 * 3. Vérifie s'il existe une version plus récente et propose « Mettre à jour ».
 *
 * Passe directement par window.__adobe_cep__ (evalScript, getSystemPath) : pas besoin de CSInterface.js.
 */
(function () {
  'use strict';

  var CLE_MAJ_FAITE = '22h30_maj_faite';
  var ETAPES = {
    telechargement: 'téléchargement…',
    empreinte: 'vérification de l\'empreinte…',
    extraction: 'décompression…',
    controle: 'contrôle du paquet…',
    sauvegarde: 'sauvegarde de la version en place…',
    remplacement: 'remplacement des fichiers…'
  };

  function el(id) { return document.getElementById(id); }

  function afficherErreurFatale(message) {
    el('maj').className = 'maj erreur';
    el('maj-message').textContent = 'Le panneau n\'a pas pu démarrer.';
    el('maj-notes').textContent = message;
    el('maj-notes').hidden = false;
    el('maj-bouton').hidden = true;
  }

  var cep = window.__adobe_cep__;
  if (!cep || typeof require !== 'function') {
    afficherErreurFatale('Ce panneau doit être ouvert dans Premiere (Fenêtre > Extensions > 22H30), avec Node.js activé.');
    return;
  }

  var fs = require('fs');
  var path = require('path');

  /* Dossier du panneau, d'après CEP (adresse file://… encodée). */
  function dossierExtension() {
    var brut = decodeURI(cep.getSystemPath('extension'));
    brut = process.platform === 'win32' ? brut.replace(/^file:\/\/\//, '') : brut.replace(/^file:\/\//, '');
    return path.normalize(brut);
  }

  function lireVersion(dossier) {
    var xml = fs.readFileSync(path.join(dossier, 'CSXS', 'manifest.xml'), 'utf8');
    var m = /ExtensionBundleVersion="([^"]+)"/.exec(xml);
    return m ? m[1] : '?';
  }

  /* Recharge un module même si Node l'a déjà en mémoire (utile après une mise à jour). */
  function chargerModule(chemin) {
    try { delete require.cache[require.resolve(chemin)]; } catch (e) { /* pas en cache */ }
    return require(chemin);
  }

  function evalScript(script, rappel) {
    cep.evalScript(script, function (resultat) { rappel(resultat); });
  }

  /* Fond du panneau = fond des panneaux de Premiere (thème clair ou sombre). */
  function appliquerTheme() {
    try {
      var env = JSON.parse(cep.getHostEnvironment());
      var c = env.appSkinInfo.panelBackgroundColor.color;
      var fond = 'rgb(' + Math.round(c.red) + ',' + Math.round(c.green) + ',' + Math.round(c.blue) + ')';
      document.documentElement.style.background = fond;
      document.body.style.background = fond;
      var clair = (c.red + c.green + c.blue) / 3 > 128;
      if (clair) {
        document.body.style.color = '#222';
        document.querySelector('h1').style.color = '#111';
      }
    } catch (e) { /* on garde les couleurs par défaut */ }
  }

  var dossier;
  var version;
  var MAJ;
  try {
    dossier = dossierExtension();
    version = lireVersion(dossier);
    MAJ = chargerModule(path.join(dossier, 'js', 'mise_a_jour.js'));
  } catch (e) {
    afficherErreurFatale(e.message);
    return;
  }

  appliquerTheme();
  el('version-panneau').textContent = 'Version ' + version;

  /* ---------- Premiere ---------- */

  function afficherVersionPremiere() {
    var hote = path.join(dossier, 'jsx', 'host.jsx').replace(/\\/g, '/').replace(/"/g, '\\"');
    evalScript('$.evalFile("' + hote + '")', function () {
      evalScript('P2230.versionPremiere()', function (reponse) {
        var ok = reponse && reponse.indexOf('EvalScript error') < 0 && reponse !== 'undefined';
        el('version-premiere').textContent = ok ? 'Premiere ' + reponse : 'Premiere : pas de réponse de host.jsx';
      });
    });
  }

  /* ---------- Fiche du jour ---------- */

  /* La fiche (version sans tests) est livrée dans le panneau : fiche/fiche_navigateur.html.
     Elle s'ouvre dans le navigateur par défaut, comme la copie du SSD jusqu'ici. */
  function ouvrirFiche() {
    var page = path.join(dossier, 'fiche', 'fiche_navigateur.html');
    var message = el('fiche-message');
    if (!fs.existsSync(page)) {
      message.textContent = 'La fiche n\'est pas dans cette version du panneau (' + version + ').';
      message.className = 'aide erreur';
      return;
    }
    var commande = process.platform === 'win32' ? 'explorer.exe' : '/usr/bin/open';
    require('child_process').execFile(commande, [page], function (err) {
      // explorer.exe répond souvent par un code 1 même quand tout va bien : on ne s'y fie pas sous Windows.
      if (err && process.platform !== 'win32') {
        message.textContent = 'La fiche n\'a pas pu s\'ouvrir : ' + err.message;
        message.className = 'aide erreur';
        return;
      }
      message.textContent = 'Fiche ouverte dans le navigateur.';
      message.className = 'aide';
    });
  }

  el('fiche-bouton').addEventListener('click', ouvrirFiche);

  /* ---------- Mises à jour ---------- */

  var publiee = null;
  var occupe = false;

  function montrer(etat, message, notes, avecBouton) {
    el('maj').className = 'maj ' + etat;
    el('maj-message').textContent = message;
    el('maj-notes').textContent = notes || '';
    el('maj-notes').hidden = !notes;
    el('maj-bouton').hidden = !avecBouton;
    el('maj-bouton').disabled = false;
  }

  function bloquer(oui) {
    occupe = oui;
    el('maj-bouton').disabled = oui;
    el('maj-verifier').className = oui ? 'inactif' : '';
  }

  function config() {
    return {
      identifiant: MAJ.IDENTIFIANT,
      versionInstallee: version,
      dossierExtension: dossier,
      adresseVersion: MAJ.adresseVersion()
    };
  }

  function verifier() {
    if (occupe) return;
    bloquer(true);
    montrer('attente', 'Recherche de mises à jour…');
    var faite = null;
    try { faite = window.localStorage.getItem(CLE_MAJ_FAITE); } catch (e) { faite = null; }

    MAJ.verifier(config(), function (err, resultat) {
      bloquer(false);
      if (err) {
        montrer('erreur', 'Impossible de vérifier les mises à jour.', err.message + ' Le panneau fonctionne avec la version installée.');
        return;
      }
      if (resultat.etat === 'aucune_publication') {
        montrer('neutre', 'Aucune version publiée pour l\'instant.', 'Le panneau fonctionne avec la version installée (' + version + ').');
        return;
      }
      if (resultat.etat === 'a_jour') {
        var note = faite === version ? 'Mise à jour réussie.' : '';
        try { window.localStorage.removeItem(CLE_MAJ_FAITE); } catch (e) { /* sans gravité */ }
        montrer('ok', 'À jour (' + version + ')', note);
        return;
      }
      publiee = resultat.publiee;
      montrer('dispo', 'Version ' + publiee.version + ' disponible', publiee.notes || '', true);
    });
  }

  function mettreAJour() {
    if (occupe || !publiee) return;
    bloquer(true);
    montrer('attente', 'Mise à jour vers ' + publiee.version + ' : début…', '', true);
    el('maj-bouton').disabled = true;

    MAJ.installer(config(), publiee, function (etape) {
      el('maj-message').textContent = 'Mise à jour vers ' + publiee.version + ' : ' + (ETAPES[etape] || etape);
    }, function (err, resultat) {
      if (err) {
        bloquer(false);
        montrer('erreur', 'La mise à jour a échoué (' + (ETAPES[err.etape] || err.etape || 'inconnue').replace(/…$/, '') + ').',
          err.message + ' La version ' + version + ' reste en place.', true);
        return;
      }
      if (resultat.redemarrer) {
        montrer('ok', 'Version ' + resultat.version + ' installée.', 'Redémarrez Premiere pour la terminer.');
        return;
      }
      try { window.localStorage.setItem(CLE_MAJ_FAITE, resultat.version); } catch (e) { /* sans gravité */ }
      montrer('ok', 'Version ' + resultat.version + ' installée.', 'Rechargement du panneau…');
      setTimeout(function () { window.location.reload(); }, 800);
    });
  }

  el('maj-bouton').addEventListener('click', mettreAJour);
  el('maj-verifier').addEventListener('click', function (evenement) {
    evenement.preventDefault();
    verifier();
  });

  if (MAJ.adresseVersion() !== MAJ.ADRESSE_VERSION) {
    el('maj-source').textContent = 'Adresse d\'essai : ' + MAJ.adresseVersion();
    el('maj-source').hidden = false;
  }

  afficherVersionPremiere();
  verifier();
})();
