/*
 * Panneau 22H30 : mise à jour sur place (Node.js).
 *
 * 1. verifier()  lit version.json sur le dépôt public et le compare à la version installée.
 * 2. installer() télécharge le zip, vérifie son empreinte SHA-256, le décompresse, contrôle le
 *    manifeste, sauvegarde la version en place, remplace les fichiers du panneau.
 *    À la moindre erreur, rien n'est remplacé, ou la sauvegarde est remise en place.
 *
 * Utilisé par js/panneau.js (contexte mixte de CEP) et par essais/essai_mise_a_jour.js (Node seul).
 * Écrit pour Node 8 (CEP 9 de Premiere 2020) : pas de fs.promises, fs.cpSync, fs.rmSync,
 * ni de mkdir récursif.
 */
'use strict';

var fs = require('fs');
var path = require('path');
var os = require('os');
var crypto = require('crypto');
var http = require('http');
var https = require('https');
var url = require('url');
var childProcess = require('child_process');

var IDENTIFIANT = 'com.damgau.22h30';
var ADRESSE_VERSION = 'https://raw.githubusercontent.com/damgau/22h30-plug-in/main/version.json';
var NOM_DOSSIER_DONNEES = '22H30-plug-in';
var DELAI_MS = 10000;
var REDIRECTIONS_MAX = 5;

/* ---------- Réglages ---------- */

/* Dossier de données du panneau, hors du dossier CEP (sinon Premiere verrait deux panneaux). */
function dossierDonnees() {
  if (process.platform === 'win32') {
    return path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), NOM_DOSSIER_DONNEES);
  }
  return path.join(os.homedir(), 'Library', 'Application Support', NOM_DOSSIER_DONNEES);
}

/* Réglages facultatifs (essais) : <dossier de données>/reglages.json, par exemple
   {"adresse_version": "http://127.0.0.1:8765/version.json"}. Absent en production. */
function reglages(dossier) {
  try {
    return JSON.parse(fs.readFileSync(path.join(dossier || dossierDonnees(), 'reglages.json'), 'utf8')) || {};
  } catch (e) {
    return {};
  }
}

function adresseVersion(dossier) {
  return reglages(dossier).adresse_version || ADRESSE_VERSION;
}

/* ---------- Outils ---------- */

function erreur(etape, message) {
  var e = new Error(message);
  e.etape = etape;
  return e;
}

/* -1, 0 ou 1, en comparant des numéros X.Y.Z. */
function comparerVersions(a, b) {
  var pa = String(a).split('.');
  var pb = String(b).split('.');
  for (var i = 0; i < 3; i++) {
    var x = parseInt(pa[i], 10) || 0;
    var y = parseInt(pb[i], 10) || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

/* Découpe une adresse pour http.get. URL moderne si elle existe, url.parse sinon (vieux Node). */
function analyserAdresse(adresse) {
  if (typeof url.URL === 'function') {
    var u = new url.URL(adresse);
    return { protocol: u.protocol, hostname: u.hostname, port: u.port || undefined, path: u.pathname + u.search };
  }
  var p = url.parse(adresse);
  return { protocol: p.protocol, hostname: p.hostname, port: p.port || undefined, path: p.path };
}

/* Adresse relative résolue par rapport à une adresse de base. */
function resoudreAdresse(base, relative) {
  if (typeof url.URL === 'function') return new url.URL(relative, base).toString();
  return url.resolve(base, relative);
}

/* Télécharge une adresse http(s) en mémoire, en suivant les redirections. */
function telecharger(adresse, rappel, profondeur) {
  profondeur = profondeur || 0;
  var fini = false;
  function finir(err, donnees) {
    if (fini) return;
    fini = true;
    rappel(err, donnees);
  }

  var options;
  try {
    options = analyserAdresse(adresse);
  } catch (e) {
    return finir(new Error('Adresse invalide : ' + adresse));
  }
  if (options.protocol !== 'https:' && options.protocol !== 'http:') {
    return finir(new Error('Adresse non prise en charge : ' + adresse));
  }
  options.headers = { 'User-Agent': '22h30-plug-in', 'Cache-Control': 'no-cache' };
  var client = options.protocol === 'http:' ? http : https;

  var requete = client.get(options, function (reponse) {
    var statut = reponse.statusCode;
    if (statut >= 300 && statut < 400 && reponse.headers.location) {
      reponse.resume();
      if (profondeur >= REDIRECTIONS_MAX) return finir(new Error('Trop de redirections.'));
      return telecharger(resoudreAdresse(adresse, reponse.headers.location), finir, profondeur + 1);
    }
    if (statut !== 200) {
      reponse.resume();
      var e = new Error('Le serveur a répondu ' + statut + '.');
      e.statut = statut;
      return finir(e);
    }
    var morceaux = [];
    reponse.on('data', function (m) { morceaux.push(m); });
    reponse.on('end', function () { finir(null, Buffer.concat(morceaux)); });
    reponse.on('aborted', function () { finir(new Error('Téléchargement interrompu.')); });
    reponse.on('error', function (e2) { finir(new Error('Téléchargement interrompu (' + e2.message + ').')); });
  });
  requete.on('error', function (e) {
    finir(new Error('Pas de connexion (' + (e.code || e.message) + ').'));
  });
  requete.setTimeout(DELAI_MS, function () {
    finir(new Error('Pas de réponse après ' + (DELAI_MS / 1000) + ' s.'));
    requete.abort();
  });
}

function existe(p) {
  try { fs.lstatSync(p); return true; } catch (e) { return false; }
}

function creerDossier(d) {
  if (existe(d)) return;
  var parent = path.dirname(d);
  if (parent !== d) creerDossier(parent);
  fs.mkdirSync(d);
}

function copierFichier(source, cible) {
  if (fs.copyFileSync) fs.copyFileSync(source, cible);
  else fs.writeFileSync(cible, fs.readFileSync(source));
}

/* Copie récursive : les fichiers de la source remplacent ceux de la cible. */
function copier(source, cible) {
  var info = fs.lstatSync(source);
  if (info.isDirectory()) {
    creerDossier(cible);
    fs.readdirSync(source).forEach(function (nom) {
      copier(path.join(source, nom), path.join(cible, nom));
    });
  } else if (info.isFile()) {
    creerDossier(path.dirname(cible));
    copierFichier(source, cible);
  }
}

function supprimer(p) {
  var info = fs.lstatSync(p);
  if (info.isDirectory()) {
    fs.readdirSync(p).forEach(function (nom) { supprimer(path.join(p, nom)); });
    fs.rmdirSync(p);
  } else {
    fs.unlinkSync(p);
  }
}

/* Supprime de la cible ce qui n'existe pas dans la référence (fichiers retirés d'une version). */
function supprimerAbsents(reference, cible) {
  fs.readdirSync(cible).forEach(function (nom) {
    var dansReference = path.join(reference, nom);
    var dansCible = path.join(cible, nom);
    if (!existe(dansReference)) {
      supprimer(dansCible);
    } else if (fs.lstatSync(dansReference).isDirectory() && fs.lstatSync(dansCible).isDirectory()) {
      supprimerAbsents(dansReference, dansCible);
    }
  });
}

/* Cherche un dossier par son nom, jusqu'à une certaine profondeur. */
function trouverDossier(racine, nom, profondeur) {
  var file = [{ chemin: racine, niveau: 0 }];
  while (file.length) {
    var courant = file.shift();
    var noms;
    try { noms = fs.readdirSync(courant.chemin); } catch (e) { continue; }
    for (var i = 0; i < noms.length; i++) {
      var chemin = path.join(courant.chemin, noms[i]);
      var estDossier = false;
      try { estDossier = fs.lstatSync(chemin).isDirectory(); } catch (e2) { estDossier = false; }
      if (!estDossier) continue;
      if (noms[i] === nom) return chemin;
      if (courant.niveau + 1 < profondeur) file.push({ chemin: chemin, niveau: courant.niveau + 1 });
    }
  }
  return null;
}

function lireManifeste(dossierPanneau) {
  var xml;
  try {
    xml = fs.readFileSync(path.join(dossierPanneau, 'CSXS', 'manifest.xml'), 'utf8');
  } catch (e) {
    return null;
  }
  var id = /ExtensionBundleId="([^"]+)"/.exec(xml);
  var version = /ExtensionBundleVersion="([^"]+)"/.exec(xml);
  return { identifiant: id ? id[1] : null, version: version ? version[1] : null };
}

function extraire(zip, destination, rappel) {
  try { creerDossier(destination); } catch (e) { return rappel(e); }
  var commande;
  var arguments_;
  if (process.platform === 'win32') {
    var guillemets = function (s) { return "'" + String(s).replace(/'/g, "''") + "'"; };
    commande = 'powershell.exe';
    arguments_ = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command',
      'Expand-Archive -LiteralPath ' + guillemets(zip) + ' -DestinationPath ' + guillemets(destination) + ' -Force'];
  } else {
    commande = '/usr/bin/ditto';
    arguments_ = ['-x', '-k', zip, destination];
  }
  childProcess.execFile(commande, arguments_, { timeout: 60000 }, function (err, sortie, erreurs) {
    if (err) return rappel(new Error('Décompression impossible (' + String(erreurs || err.message).trim() + ').'));
    rappel(null);
  });
}

/* ---------- Vérifier ---------- */

function controlerInfo(info, identifiant) {
  if (!info || typeof info !== 'object') return 'version.json est vide.';
  if (info.identifiant !== identifiant) return 'version.json concerne une autre extension.';
  if (!/^\d+\.\d+\.\d+$/.test(info.version || '')) return 'Numéro de version invalide dans version.json.';
  if (typeof info.zip !== 'string' || !info.zip) return 'Adresse du zip absente de version.json.';
  if (!/^[0-9a-f]{64}$/.test(info.sha256 || '')) return 'Empreinte SHA-256 absente ou invalide dans version.json.';
  return null;
}

/*
 * config : { versionInstallee, identifiant?, adresseVersion? }
 * rappel(err, { etat: 'a_jour' | 'disponible' | 'aucune_publication', publiee })
 */
function verifier(config, rappel) {
  var adresse = config.adresseVersion || ADRESSE_VERSION;
  var identifiant = config.identifiant || IDENTIFIANT;
  var separateur = adresse.indexOf('?') < 0 ? '?' : '&';
  telecharger(adresse + separateur + 't=' + Date.now(), function (err, donnees) {
    if (err) {
      if (err.statut === 404) return rappel(null, { etat: 'aucune_publication' });
      return rappel(erreur('verification', err.message));
    }
    var info;
    try {
      info = JSON.parse(donnees.toString('utf8'));
    } catch (e) {
      return rappel(erreur('verification', 'version.json est illisible.'));
    }
    var probleme = controlerInfo(info, identifiant);
    if (probleme) return rappel(erreur('verification', probleme));
    try {
      info.adresseZip = resoudreAdresse(adresse, info.zip);
    } catch (e2) {
      return rappel(erreur('verification', 'Adresse du zip invalide dans version.json.'));
    }
    var plusRecente = comparerVersions(info.version, config.versionInstallee) > 0;
    rappel(null, { etat: plusRecente ? 'disponible' : 'a_jour', publiee: info });
  });
}

/* ---------- Installer ---------- */

/*
 * config : { dossierExtension, identifiant?, dossierDonnees? }
 * info : la version publiée renvoyée par verifier() (avec adresseZip).
 * progression(etape) : 'telechargement', 'empreinte', 'extraction', 'controle', 'sauvegarde', 'remplacement'.
 * rappel(err, { version, redemarrer, sauvegarde }) ; err.etape dit où ça a échoué.
 */
function installer(config, info, progression, rappel) {
  progression = progression || function () {};
  var identifiant = config.identifiant || IDENTIFIANT;
  var cible = config.dossierExtension;
  var donnees = config.dossierDonnees || dossierDonnees();
  var temporaire = null;

  function nettoyer() {
    if (temporaire) {
      try { supprimer(temporaire); } catch (e) { /* sans gravité */ }
      temporaire = null;
    }
  }
  function echec(etape, message) {
    nettoyer();
    rappel(erreur(etape, message));
  }

  // Garde-fou : ne jamais écrire ailleurs que dans le dossier du panneau.
  if (!cible || path.basename(cible) !== identifiant || !existe(path.join(cible, 'CSXS', 'manifest.xml'))) {
    return echec('controle', 'Dossier du panneau inattendu : ' + cible);
  }

  progression('telechargement');
  telecharger(info.adresseZip, function (err, zip) {
    if (err) return echec('telechargement', err.message);

    progression('empreinte');
    var empreinte = crypto.createHash('sha256').update(zip).digest('hex');
    if (empreinte !== info.sha256) {
      return echec('empreinte', 'Empreinte différente : le fichier téléchargé est abîmé ou a été modifié. Il est refusé.');
    }

    progression('extraction');
    var fichierZip;
    try {
      temporaire = fs.mkdtempSync(path.join(os.tmpdir(), '22h30-maj-'));
      fichierZip = path.join(temporaire, 'paquet.zip');
      fs.writeFileSync(fichierZip, zip);
    } catch (e) {
      return echec('extraction', e.message);
    }
    extraire(fichierZip, path.join(temporaire, 'extrait'), function (err2) {
      if (err2) return echec('extraction', err2.message);

      progression('controle');
      var nouveau = trouverDossier(path.join(temporaire, 'extrait'), identifiant, 3);
      if (!nouveau) return echec('controle', 'Le paquet ne contient pas le dossier ' + identifiant + '.');
      var manifeste = lireManifeste(nouveau);
      if (!manifeste) return echec('controle', 'Le paquet ne contient pas de manifeste.');
      if (manifeste.identifiant !== identifiant) {
        return echec('controle', 'Le paquet contient une autre extension (' + manifeste.identifiant + ').');
      }
      if (manifeste.version !== info.version) {
        return echec('controle', 'Le paquet contient la version ' + manifeste.version + ' au lieu de ' + info.version + '.');
      }

      progression('sauvegarde');
      var sauvegarde = path.join(donnees, 'precedente');
      try {
        creerDossier(donnees);
        if (existe(sauvegarde)) supprimer(sauvegarde);
        copier(cible, sauvegarde);
      } catch (e3) {
        return echec('sauvegarde', e3.message);
      }

      progression('remplacement');
      try {
        copier(nouveau, cible);
        supprimerAbsents(nouveau, cible);
      } catch (e4) {
        var suite;
        try {
          copier(sauvegarde, cible);
          supprimerAbsents(sauvegarde, cible);
          suite = ' La version précédente a été remise en place.';
        } catch (e5) {
          suite = ' La version précédente n\'a pas pu être remise : la recopier à la main depuis ' + sauvegarde + '.';
        }
        return echec('remplacement', e4.message + '.' + suite);
      }

      nettoyer();
      rappel(null, { version: info.version, redemarrer: !!info.redemarrer_premiere, sauvegarde: sauvegarde });
    });
  });
}

module.exports = {
  IDENTIFIANT: IDENTIFIANT,
  ADRESSE_VERSION: ADRESSE_VERSION,
  dossierDonnees: dossierDonnees,
  reglages: reglages,
  adresseVersion: adresseVersion,
  comparerVersions: comparerVersions,
  lireManifeste: lireManifeste,
  verifier: verifier,
  installer: installer,
  // Pour les essais.
  _outils: { extraire: extraire, copier: copier, supprimer: supprimer, existe: existe, creerDossier: creerDossier }
};
