#!/bin/bash
# Installe le panneau 22H30 pour Premiere (macOS), une seule fois.
# - copie le dossier com.damgau.22h30 dans le dossier CEP de l'utilisateur (sans droits d'administrateur) ;
# - active le mode débogage CEP (PlayerDebugMode), qui autorise un panneau non signé par Adobe.
# Ensuite, les nouvelles versions arrivent par le bouton « Mettre à jour » du panneau.

ICI="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$ICI/com.damgau.22h30"
PARENT="$HOME/Library/Application Support/Adobe/CEP/extensions"
CIBLE="$PARENT/com.damgau.22h30"
DONNEES="$HOME/Library/Application Support/22H30-plug-in"

pause() {
  if [ -t 0 ]; then
    echo
    read -n 1 -s -r -p "Appuyez sur une touche pour fermer cette fenêtre."
    echo
  fi
}

echo "Installation du panneau 22H30 pour Premiere"
echo

if [ ! -f "$SOURCE/CSXS/manifest.xml" ]; then
  echo "Erreur : le dossier com.damgau.22h30 est introuvable à côté de ce script."
  echo "Décompressez d'abord le zip, puis lancez ce script depuis le dossier décompressé."
  pause
  exit 1
fi

if pgrep -f "Adobe Premiere Pro" > /dev/null 2>&1; then
  echo "Attention : Premiere est ouvert. Il faudra le redémarrer après l'installation."
  echo
fi

mkdir -p "$PARENT" || { echo "Erreur : impossible de créer $PARENT"; pause; exit 1; }

if [ -d "$CIBLE" ]; then
  mkdir -p "$DONNEES"
  rm -rf "$DONNEES/precedente"
  mv "$CIBLE" "$DONNEES/precedente" || { echo "Erreur : impossible de mettre de côté l'ancienne version."; pause; exit 1; }
  echo "Ancienne version mise de côté dans : $DONNEES/precedente"
fi

cp -R "$SOURCE" "$CIBLE" || { echo "Erreur : la copie a échoué."; pause; exit 1; }
xattr -dr com.apple.quarantine "$CIBLE" 2> /dev/null

# CSXS 9 = Premiere 2020 ; CSXS 12 = Premiere 25 et 26. Les autres numéros sont sans effet s'ils ne servent pas.
for v in 9 10 11 12 13; do
  defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1
done
killall cfprefsd 2> /dev/null

VERSION=$(sed -n 's/.*ExtensionBundleVersion="\([^"]*\)".*/\1/p' "$CIBLE/CSXS/manifest.xml" | head -n 1)
echo "Terminé : panneau 22H30, version $VERSION."
echo "Installé dans : $CIBLE"
echo
echo "Redémarrez Premiere, puis ouvrez Fenêtre > Extensions > 22H30."
pause
