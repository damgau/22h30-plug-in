/*
 * Panneau 22H30 : le nom de la séquence maître (Node.js, sans Premiere : testable par essais/essai_sequence_maitre.js).
 *
 * Premiere propose comme nom de fichier exporté le nom de la séquence maître. Si la séquence s'appelle
 * exactement « AVC-MAT-nnnnnn », la fenêtre d'export propose « AVC-MAT-nnnnnn.mxf ». Erreurs vécues :
 *   04/11 : « ␣AVC-MAT-008382 » (espace venue du conducteur) → fichier mal nommé, arrivé au mauvais endroit ;
 *   05/11 : « AVC-MAT-008387.mxf » → Premiere proposait « AVC-MAT-008387.mxf.mxf ».
 * Le panneau compare le nom au code de la fiche et propose de renommer (bouton, jsx/host.jsx).
 * Écrit pour Node 8 (CEP 9).
 */
'use strict';

var MOTIF_EXPORT = /^AVC-MAT-\d{6}\.mxf$/;
var MOTIF_CODE = /AVC-MAT-\d{6}/i;

/* « AVC-MAT-008387.mxf » (nom d'export de la fiche) → « AVC-MAT-008387 », sinon null. */
function nomAttendu(exportFiche) {
  return typeof exportFiche === 'string' && MOTIF_EXPORT.test(exportFiche) ? exportFiche.slice(0, -4) : null;
}

/* Réponse de P2230.sequences() : une ligne « identifiant<TAB>nom » par séquence. */
function lireListe(texte) {
  return String(texte || '').split('\n').filter(function (l) { return l.indexOf('\t') > 0; }).map(function (l) {
    var i = l.indexOf('\t');
    return { id: l.slice(0, i), nom: l.slice(i + 1) };
  });
}

/* Espaces du début et de la fin rendues visibles : « ␣AVC-MAT-008382 ». */
function visible(nom) {
  return String(nom).replace(/^\s+|\s+$/g, function (espaces) { return espaces.replace(/\s/g, '␣'); });
}

/* La séquence maître : la seule dont le nom contient « AVC-MAT » (le template la nomme « AVC-MAT-XXX »).
   Si plusieurs, celle qui porte déjà le nom attendu ; sinon, c'est ambigu. */
function choisirMaitre(sequences, attendu) {
  var candidates = sequences.filter(function (s) { return /AVC-MAT/i.test(s.nom); });
  if (candidates.length === 1) return { maitre: candidates[0], candidates: candidates };
  if (candidates.length > 1) {
    var exacte = candidates.filter(function (s) { return s.nom === attendu; });
    if (exacte.length === 1) return { maitre: exacte[0], candidates: candidates };
    return { maitre: null, candidates: candidates, probleme: 'plusieurs' };
  }
  return { maitre: null, candidates: [], probleme: 'aucune' };
}

/* Le nom est-il juste ? Sinon, pourquoi (texte court pour le panneau). */
function etatNom(nom, attendu) {
  if (nom === attendu) return { juste: true, raison: '' };
  var net = String(nom).replace(/^\s+|\s+$/g, '');
  var raison;
  if (net === attendu) {
    raison = 'espace en trop (« ' + visible(nom) + ' ») : le fichier exporté prendrait cette espace';
  } else if (/\.mxf$/i.test(net) && net.slice(0, -4) === attendu) {
    raison = 'extension « .mxf » en trop : Premiere proposerait « ' + net + '.mxf »';
  } else if (/AVC-MAT-X+$/i.test(net)) {
    raison = 'nom du template, pas encore le code du jour';
  } else if (MOTIF_CODE.test(net) && net.match(MOTIF_CODE)[0].toUpperCase() !== attendu) {
    raison = 'code d\'un autre numéro (' + net.match(MOTIF_CODE)[0] + ')';
  } else {
    raison = 'pas exactement le code du jour';
  }
  return { juste: false, raison: raison };
}

/* Texte entre guillemets pour un appel ExtendScript (evalScript) : guillemets et barres échappés,
   caractères non ASCII en \uXXXX (ExtendScript les comprend, l'envoi du texte brut est moins sûr). */
function litteral(texte) {
  return JSON.stringify(String(texte)).replace(/[\u007f-￿]/g, function (c) {
    return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
  });
}

/* Message de la fenêtre d'alerte, une fois, après le renommage. */
function messageApresRenommage(attendu) {
  return 'Séquence maître nommée « ' + attendu + ' ».\n\nÀ l\'export, vérifie le nom du fichier : exactement « ' +
    attendu + '.mxf », rien avant, rien après.';
}

module.exports = {
  nomAttendu: nomAttendu,
  lireListe: lireListe,
  visible: visible,
  choisirMaitre: choisirMaitre,
  etatNom: etatNom,
  litteral: litteral,
  messageApresRenommage: messageApresRenommage
};
