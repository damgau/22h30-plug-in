/*
 * Panneau 22H30 : tout ce qui parle à Premiere (ExtendScript).
 *
 * C'est le seul fichier qui agit sur Premiere. Le jour où le bureau passera en Premiere 27,
 * c'est lui qu'il faudra réécrire pour UXP ; le reste du panneau ne changera pas.
 *
 * Le panneau le charge à chaque ouverture ($.evalFile), pour qu'une mise à jour le recharge aussi.
 * Tout est rangé dans l'objet P2230, pour ne pas gêner les autres extensions.
 *
 * ExtendScript est un JavaScript ancien (ES3) : ni let, ni JSON garanti, ni String.trim, ni Array.indexOf.
 * Les réponses sont donc du texte simple.
 */

var P2230 = P2230 || {};

/* Étape 1 : une seule fonction, qui prouve que le pont panneau ↔ Premiere fonctionne. */
P2230.versionPremiere = function () {
    return String(app.version);
};

/* Chemin complet du projet ouvert (.prproj), ou "" si aucun projet n'est enregistré. Lecture seule. */
P2230.cheminProjet = function () {
    if (!app.project || !app.project.path) return "";
    return String(app.project.path);
};

/* Séquences du projet ouvert : une ligne par séquence, « identifiant<TAB>nom ». Lecture seule. */
P2230.sequences = function () {
    if (!app.project || !app.project.sequences) return "";
    var seqs = app.project.sequences;
    var lignes = [];
    for (var i = 0; i < seqs.numSequences; i++) {
        lignes.push(String(seqs[i].sequenceID) + "\t" + String(seqs[i].name));
    }
    return lignes.join("\n");
};

/* Renomme une séquence (identifiant donné par P2230.sequences), seulement quand on clique sur le bouton
   du panneau. Renvoie le nom relu dans Premiere, ou "" si la séquence n'est plus dans le projet. */
P2230.renommerSequence = function (id, nom) {
    if (!app.project || !app.project.sequences) return "";
    var seqs = app.project.sequences;
    for (var i = 0; i < seqs.numSequences; i++) {
        var s = seqs[i];
        if (String(s.sequenceID) === id) {
            s.name = nom;
            if (String(s.name) !== nom && s.projectItem) s.projectItem.name = nom;
            return String(s.name);
        }
    }
    return "";
};

/* Fenêtre d'alerte de Premiere. */
P2230.alerte = function (texte) {
    alert(texte, "22H30");
    return "ok";
};
